function calcular1(){
    const num1= parseFloat(document.getElementById("num1").value);
    const num2= parseFloat(document.getElementById("num2").value);
    const resultado= num1*num2 / 2
    document.getElementById("resultado").innerText = "resultado "+ resultado + "u";
};
function calcular2(){
    const num1= parseFloat(document.getElementById("num1").value);
    const num2= parseFloat(document.getElementById("num2").value);
    const resultado= num1/num2
    document.getElementById("resultado").innerText = num1 + " pesos son "+ resultado + "dolares";
};
let x=0
function calcular3(){
    const num1= parseFloat(document.getElementById("num1").value);
    const num2= parseFloat(document.getElementById("num2").value);
    const resultado= num2-num1
    x= x+1
    document.getElementById("resultado").innerText += "empleado "+ x + " edad:"+ resultado+ "\n";
};
function calcular4(){
    const num1= parseFloat(document.getElementById("num1").value);
    let numI= parseInt(document.getElementById("num1").value);
    const num2= parseFloat(document.getElementById("num2").value);
    if (num1-numI >0) {numI= numI+1}
    const resultado= num2*numI
    document.getElementById("resultado").innerText = "tendra que pagar "+ resultado + " pesos";
};
function calcular5(){
    const num1= parseFloat(document.getElementById("num1").value);
    const num2= parseFloat(document.getElementById("num2").value);
    const resultado= num2*num1
    document.getElementById("resultado").innerText = "debera pagar "+ resultado;
};
function calcular6(){
    const num1= parseFloat(document.getElementById("num1").value);
    const num2= parseFloat(document.getElementById("num2").value);
    const resultado= Math.sqrt((num1*num1)+(num2*num2))
    document.getElementById("resultado").innerText ="hipotenusa = "+ resultado;
};
function calcular7(){
    const num1= parseFloat(document.getElementById("num1").value);
    const num2= parseFloat(document.getElementById("num2").value);
    const resultado=num2*num1
    document.getElementById("resultado").innerText ="precio total = $"+ resultado;
};
function calcular8(){
    const num1= parseFloat(document.getElementById("num1").value);
    const num2= parseFloat(document.getElementById("num2").value);
    const resultado=num2/num1
    document.getElementById("resultado").innerText ="tiempo = "+ resultado+" horas";
};
function calcular9(){
    const num1= parseFloat(document.getElementById("num1").value);
    const num2= parseFloat(document.getElementById("num2").value);
    const resultado=num1*num2
    document.getElementById("resultado").innerText ="coste de la llamada = $"+ resultado;
};